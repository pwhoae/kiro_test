/**
 * Category routes — TODO: Implement these endpoints.
 *
 * Refer to API_SPEC.md for detailed request/response specifications.
 *
 * Endpoints to implement:
 *
 * GET /api/categories
 *   - List all categories
 *   - Response: { categories: [{ id, name }, ...] }
 */

const express = require('express');
const router = express.Router();

// TODO: Implement the categories endpoint described above.
// You can access the database via: const { getDb } = require('../db/connection');

module.exports = router;
