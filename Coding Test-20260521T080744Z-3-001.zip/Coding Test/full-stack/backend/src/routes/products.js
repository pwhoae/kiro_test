/**
 * Product routes — TODO: Implement these endpoints.
 *
 * Refer to API_SPEC.md for detailed request/response specifications.
 *
 * Endpoints to implement:
 *
 * GET /api/products
 *   - List products with optional filtering and pagination
 *   - Query params: page (default 1), limit (default 10), category_id, search
 *   - "search" should match product name case-insensitively (partial match)
 *   - Response: { products: [...], total, page, totalPages }
 *
 * GET /api/products/:id
 *   - Get a single product by ID
 *   - Response should include the category name and inventory quantity
 *   - Return 404 if product not found
 *
 * POST /api/products
 *   - Create a new product
 *   - Required fields: name, price, sku
 *   - Validation: name must be non-empty, price must be > 0, sku must be unique
 *   - Return 201 on success, 400 on validation error
 *
 * PUT /api/products/:id
 *   - Update an existing product (partial update)
 *   - Return 404 if product not found
 *   - Return the updated product
 *
 * DELETE /api/products/:id
 *   - Delete a product by ID
 *   - Return 204 on success, 404 if not found
 */

const express = require('express');
const router = express.Router();

// TODO: Implement the product endpoints described above.
// You can access the database via: const { getDb } = require('../db/connection');

module.exports = router;
