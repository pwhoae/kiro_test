/**
 * Stats route — TODO: Implement this endpoint.
 *
 * Refer to API_SPEC.md for detailed request/response specifications.
 *
 * Endpoints to implement:
 *
 * GET /api/stats
 *   - Return aggregate statistics about the product catalog
 *   - Response: {
 *       totalProducts: <number>,
 *       totalCategories: <number>,
 *       avgPrice: <number (rounded to 2 decimal places)>,
 *       outOfStockCount: <number (products with inventory quantity = 0)>
 *     }
 */

const express = require('express');
const router = express.Router();

// TODO: Implement the stats endpoint described above.
// You can access the database via: const { getDb } = require('../db/connection');

module.exports = router;
