/**
 * Product List Page — TODO: Implement this component.
 *
 * Requirements:
 *   1. Fetch products from GET /api/products on page load
 *   2. Display products in a table or card/grid layout
 *   3. Each product should show: name, price, and category
 *   4. Add a search input that filters products via the API
 *      (call GET /api/products?search=<query> when the user types)
 *   5. Each product should link to its detail page at /products/:id
 *
 * Required data-testid attributes (used by automated tests):
 *   - "product-card"   → on each product item/row in the list
 *   - "product-name"   → on the product name text within each item
 *   - "product-price"  → on the product price text within each item
 *   - "search-input"   → on the search input field
 *
 * Example usage of the API client:
 *   import api from '../api/client';
 *   const data = await api.get('/api/products');
 *   // data = { products: [...], total, page, totalPages }
 *
 *   const filtered = await api.get('/api/products', { search: 'headphones' });
 */

function ProductList() {
  // TODO: Implement the product list page
  return (
    <div>
      <h1>Products</h1>
      <p>TODO: Implement this page. See the comments above for requirements.</p>
    </div>
  );
}

export default ProductList;
