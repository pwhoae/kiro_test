/**
 * Product Detail Page — TODO: Implement this component.
 *
 * Requirements:
 *   1. Read the product ID from the URL (useParams from react-router-dom)
 *   2. Fetch the product from GET /api/products/:id
 *   3. Display all product fields: name, price, description, SKU, category, stock quantity
 *   4. Show a link back to the product list
 *
 * Required data-testid attributes (used by automated tests):
 *   - "product-detail-name"   → on the product name element
 *   - "product-detail-price"  → on the product price element
 *
 * Example usage:
 *   import { useParams } from 'react-router-dom';
 *   import api from '../api/client';
 *
 *   const { id } = useParams();
 *   const product = await api.get(`/api/products/${id}`);
 *   // product = { id, name, price, description, sku, image_url, category_name, quantity }
 */

function ProductDetail() {
  // TODO: Implement the product detail page
  return (
    <div>
      <h1>Product Detail</h1>
      <p>TODO: Implement this page. See the comments above for requirements.</p>
    </div>
  );
}

export default ProductDetail;
