"""
Data Science Coding Test — TODO: Implement the functions below.

Each function has a defined signature and return type. The automated tests
depend on these exact return types. You may add helper functions, but do NOT
change the signatures of the designated functions.

You MUST also complete notebook.ipynb with your EDA, explanations, and
visualizations.
"""
import os
import sys
import numpy as np
import pandas as pd

# Allow imports from this directory
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from data_loader import load_all
from holdout_config import TRAIN_END_DATE, TEST_START_DATE, TEST_END_DATE, HOLDOUT_HORIZON


# ═══════════════════════════════════════════════════════════════════════════
# Part 1: EDA & Business Overview (~30 min)
# ═══════════════════════════════════════════════════════════════════════════

def get_business_overview() -> dict:
    """
    Calculate key business metrics for delivered orders.

    Returns:
        dict with keys:
            - 'total_revenue' (float): sum of (price + freight_value) for all
              delivered orders
            - 'total_orders' (int): number of distinct delivered orders
            - 'avg_order_value' (float): total_revenue / total_orders
            - 'revenue_by_month' (pd.DataFrame): monthly revenue with columns:
                  'month' (pd.Timestamp): first day of each month
                  'revenue' (float): total revenue that month
              Sorted by month ascending.

    Notes:
        - Only include orders with order_status == 'delivered'.
        - Revenue = price + freight_value (from order_items table).
        - Use order_purchase_timestamp for the month.
    """
    # TODO: Implement this function
    raise NotImplementedError


# ═══════════════════════════════════════════════════════════════════════════
# Part 2: Demand Forecasting (~1 hr)
# ═══════════════════════════════════════════════════════════════════════════

def prepare_monthly_demand() -> pd.DataFrame:
    """
    Aggregate delivered orders into monthly demand (order counts per month).

    Returns:
        pd.DataFrame with columns:
            - 'month' (pd.Timestamp): first day of each month (e.g., 2017-01-01)
            - 'order_count' (int): number of delivered orders placed that month
        Sorted by month ascending.

    Notes:
        - Only include orders with order_status == 'delivered'.
        - Use order_purchase_timestamp for the date.
        - Each order_id counts once (even if it has multiple items).
    """
    # TODO: Implement this function
    raise NotImplementedError


def forecast_demand(train: pd.DataFrame, horizon: int) -> dict:
    """
    Build a forecasting model and predict the next `horizon` months of demand.

    You may use any method: ARIMA, SARIMA, Holt-Winters, Prophet, XGBoost
    with lag features, or any other approach. Justify your choice in the
    notebook.

    Args:
        train: DataFrame from prepare_monthly_demand(), filtered to the
               training period only (up through TRAIN_END_DATE).
        horizon: number of months to forecast.

    Returns:
        dict with keys:
            - 'model_name' (str): name of the model used,
              e.g., 'SARIMA(1,1,1)(1,1,1,12)' or 'Holt-Winters'
            - 'predictions' (list[float]): predicted order counts,
              length must equal `horizon`
            - 'rmse' (float): root mean squared error on the holdout period
            - 'mae' (float): mean absolute error on the holdout period

    Notes:
        - Compute RMSE and MAE by comparing your predictions against the
          actual holdout values (the months after TRAIN_END_DATE).
        - Use prepare_monthly_demand() to get the full time series, then
          split using the dates in holdout_config.py.
    """
    # TODO: Implement this function
    raise NotImplementedError


# ═══════════════════════════════════════════════════════════════════════════
# Part 3: LLM-Assisted Recommendations (~45 min)
# ═══════════════════════════════════════════════════════════════════════════

def build_analysis_context() -> str:
    """
    Compile your findings from Parts 1 and 2 into a structured text summary
    that you will use as context for prompting an LLM.

    Returns:
        str: A text summary of your analysis findings. Should include:
            - Key business metrics (from Part 1)
            - Notable patterns or trends you found (from your EDA)
            - Demand forecast results (from Part 2)
            - Any other observations relevant to business recommendations

    Notes:
        - This string will be passed as context to an LLM in
          generate_recommendations().
        - The better you structure this context, the better the LLM's
          recommendations will be.
        - Include specific numbers and data points, not vague summaries.
    """
    # TODO: Implement this function
    raise NotImplementedError


def generate_recommendations() -> dict:
    """
    Use a free LLM via OpenRouter to generate business recommendations
    based on your analysis.

    Setup:
        1. Create a free account at https://openrouter.ai/
        2. Get an API key
        3. Add it to your .env file: OPENROUTER_API_KEY=your_key_here
        4. Use any free model (e.g., a model with ':free' suffix)

    Returns:
        dict with keys:
            - 'model_used' (str): the model identifier you used,
              e.g., 'meta-llama/llama-3.1-8b-instruct:free'
            - 'prompt' (str): the full prompt you sent to the LLM
            - 'recommendations' (list[dict]): 3-5 recommendations, each with:
                  'action' (str): concise recommended action
                  'rationale' (str): why this action, backed by your data
                  'priority' (str): one of 'high', 'medium', 'low'

    Notes:
        - Use build_analysis_context() to get the context for your prompt.
        - The OpenRouter API is compatible with the OpenAI API format.
          Endpoint: https://openrouter.ai/api/v1/chat/completions
        - You can use the `requests` library or the `openai` library.
        - Store your API key in a .env file (never hardcode it).
        - We evaluate: how well you structured your prompt, whether the
          recommendations are relevant to the actual data, and whether
          you parsed the LLM output cleanly.
    """
    # TODO: Implement this function
    raise NotImplementedError
