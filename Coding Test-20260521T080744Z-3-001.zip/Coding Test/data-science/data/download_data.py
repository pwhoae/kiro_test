"""
Download the Olist Brazilian E-Commerce dataset from Kaggle.

Prerequisites:
    pip install kaggle
    Set up your Kaggle API credentials:
    https://www.kaggle.com/docs/api#authentication

Usage:
    python download_data.py
"""
import os
import sys
import zipfile
import subprocess

DATA_DIR = os.path.dirname(os.path.abspath(__file__))

EXPECTED_FILES = [
    "olist_orders_dataset.csv",
    "olist_order_items_dataset.csv",
    "olist_products_dataset.csv",
    "olist_sellers_dataset.csv",
    "olist_customers_dataset.csv",
    "olist_order_reviews_dataset.csv",
    "olist_order_payments_dataset.csv",
    "olist_geolocation_dataset.csv",
    "product_category_name_translation.csv",
]


def check_existing():
    """Check if all CSVs already exist."""
    missing = [f for f in EXPECTED_FILES if not os.path.exists(os.path.join(DATA_DIR, f))]
    return missing


def download():
    """Download and extract the dataset."""
    missing = check_existing()
    if not missing:
        print("All dataset files already present. Skipping download.")
        return

    print("Downloading Olist dataset from Kaggle...")
    try:
        subprocess.run(
            [
                "kaggle", "datasets", "download",
                "-d", "olistbr/brazilian-ecommerce",
                "-p", DATA_DIR,
            ],
            check=True,
        )
    except FileNotFoundError:
        print("Error: 'kaggle' CLI not found. Install it with: pip install kaggle")
        print("Then set up credentials: https://www.kaggle.com/docs/api#authentication")
        sys.exit(1)
    except subprocess.CalledProcessError as e:
        print(f"Error downloading dataset: {e}")
        sys.exit(1)

    # Extract zip
    zip_path = os.path.join(DATA_DIR, "brazilian-ecommerce.zip")
    if os.path.exists(zip_path):
        print("Extracting...")
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(DATA_DIR)
        os.remove(zip_path)

    # Verify
    missing = check_existing()
    if missing:
        print(f"Warning: Missing files after download: {missing}")
        sys.exit(1)

    print(f"Done! {len(EXPECTED_FILES)} CSV files ready in {DATA_DIR}/")


if __name__ == "__main__":
    download()
