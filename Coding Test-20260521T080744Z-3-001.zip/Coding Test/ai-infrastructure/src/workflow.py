"""
Customer Support Workflow — TODO: Implement the 4 functions below.

Build a LangGraph StateGraph that processes customer support messages.
Your workflow should classify the intent, route appropriately, generate
a response, and decide whether escalation is needed.

You MUST use LangGraph's StateGraph to build this workflow.
You may add as many helper functions, nodes, and edges as you want.
Do NOT change the signatures of the 4 designated functions below.

Provided utilities (import and use these):
    from state import SupportState
    from config import INTENT_CATEGORIES, PRIORITY_LEVELS, ESCALATION_SIGNALS
    from llm import call_llm
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from state import SupportState
from config import (
    INTENT_CATEGORIES,
    PRIORITY_LEVELS,
    ESCALATION_SIGNALS,
    SAMPLE_MESSAGES,
)
from llm import call_llm


# ═══════════════════════════════════════════════════════════════════════════
# Part 1: Graph Architecture (~45 min)
# ═══════════════════════════════════════════════════════════════════════════

def build_graph():
    """
    Build and return a compiled LangGraph StateGraph for the customer
    support workflow.

    Your graph must:
        - Use SupportState as the state schema
        - Have at least 2 nodes
        - Have edges connecting the nodes (conditional or direct)
        - Compile successfully (call .compile() before returning)

    The returned graph should be ready to invoke with:
        result = graph.invoke({"customer_message": "some message"})

    Returns:
        A compiled LangGraph StateGraph.

    Hints:
        - Think about what steps a human support agent would follow
        - Consider which steps need LLM calls vs. simple logic
        - Use conditional edges for routing based on intent or priority
    """
    # TODO: Implement this function
    raise NotImplementedError("Implement build_graph()")


# ═══════════════════════════════════════════════════════════════════════════
# Part 2: Node Implementation (~1 hr)
# ═══════════════════════════════════════════════════════════════════════════

def classify_intent(message: str) -> str:
    """
    Classify the intent of a customer message.

    Use the LLM (via call_llm) to determine the customer's intent.
    The returned intent MUST be one of the values in INTENT_CATEGORIES:
        'refund', 'shipping', 'product_inquiry', 'complaint', 'general'

    Args:
        message: The raw customer message text.

    Returns:
        str: One of the valid intent categories.
    """
    # TODO: Implement this function
    raise NotImplementedError("Implement classify_intent()")


def should_escalate(state: dict) -> bool:
    """
    Determine whether a customer message should be escalated to a human.

    Consider factors like:
        - Angry or threatening tone
        - Legal threats
        - Repeated issues (mentions of "again", "third time", etc.)
        - High-value or complex issues

    You may use the LLM, rule-based logic, or a combination.

    Args:
        state: The current SupportState dict (has customer_message, intent,
               sentiment, priority, etc.)

    Returns:
        bool: True if the ticket should be escalated, False otherwise.
    """
    # TODO: Implement this function
    raise NotImplementedError("Implement should_escalate()")


# ═══════════════════════════════════════════════════════════════════════════
# Part 3: End-to-End Execution (~30 min)
# ═══════════════════════════════════════════════════════════════════════════

def process_message(message: str) -> dict:
    """
    Process a single customer message through the full workflow.

    This is the main entry point. Build the graph, run the message through
    it, and return the final state.

    Args:
        message: The raw customer message text.

    Returns:
        dict matching SupportState with all fields populated:
            - customer_message (str): the original message
            - intent (str): one of INTENT_CATEGORIES
            - sentiment (str): one of 'positive', 'neutral', 'negative', 'angry'
            - priority (str): one of PRIORITY_LEVELS
            - response (str): customer-facing response (non-empty)
            - escalate (bool): whether to escalate
            - reasoning (str): explanation of the routing decision

    Example:
        result = process_message("I want a refund for order #123")
        assert result["intent"] == "refund"
        assert isinstance(result["response"], str)
        assert len(result["response"]) > 0
    """
    # TODO: Implement this function
    raise NotImplementedError("Implement process_message()")
