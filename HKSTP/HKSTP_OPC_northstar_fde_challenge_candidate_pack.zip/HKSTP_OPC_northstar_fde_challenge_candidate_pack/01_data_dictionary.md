# Data Dictionary

All files are in `/data`. Dates are exports as pulled from source systems — you may
notice they're not always internally consistent, which is realistic.

## orders.csv
| column | description |
|---|---|
| order_id | unique order identifier |
| customer_id | foreign key to customers.csv |
| order_date | when the order was placed |
| sku | foreign key to products.csv |
| qty | quantity ordered |
| warehouse | fulfilling warehouse (WH-01 / WH-02 / WH-03) |
| promised_delivery_date | delivery date promised to the customer |

## shipping_events.csv
| column | description |
|---|---|
| shipment_id | unique event identifier |
| order_id | foreign key to orders.csv |
| event_type | Picked / Packed / Delayed / Shipped / Delivered |
| event_timestamp | when the event occurred |
| carrier | shipping carrier used |
| warehouse | warehouse the event occurred at (as recorded in the WMS export — format may vary from orders.csv) |
| notes | free-text notes, mostly blank, sometimes containing context on delays |

## support_tickets.csv
| column | description |
|---|---|
| ticket_id | unique ticket identifier |
| created_at | when the ticket was opened |
| channel | email / chat / phone |
| customer_name_or_account | free text as entered by the support agent — not always a clean match to customers.csv |
| order_id_ref | order the ticket references, as entered by the agent (sometimes blank, sometimes mistyped) |
| category | ticket category as tagged by the agent |
| priority | priority as tagged by the agent |
| body | free-text complaint |

## inventory_snapshot.csv
| column | description |
|---|---|
| sku | foreign key to products.csv |
| warehouse | warehouse code |
| on_hand_qty | units on hand at last count |
| reorder_point | reorder threshold |
| last_updated | when this row was last refreshed in the source system |

## customers.csv
| column | description |
|---|---|
| customer_id | unique customer identifier |
| customer_name | display name |
| segment | B2B / B2C |
| region | West / Midwest / Northeast / South |

## products.csv
| column | description |
|---|---|
| sku | unique product identifier |
| product_name | display name |
| category | product category |

**Notes candidates have flagged in past runs of similar exercises** (shared here so
you don't burn your Q&A window on things you can discover yourself):
- Support ticket categories are agent-entered and not always reliable — read the
  `body` field, don't just trust the `category` column.
- Warehouse codes are not formatted the same way across files.
- Not everything joins cleanly on the first try. That's real data, not a puzzle
  with a hidden trick — just handle it the way you would on the job.
