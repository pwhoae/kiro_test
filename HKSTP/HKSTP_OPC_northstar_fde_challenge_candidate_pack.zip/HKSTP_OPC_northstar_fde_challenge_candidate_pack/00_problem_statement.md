# Northstar Retail Co. — Operations Visibility Challenge
### A one-day hackathon problem for the Forward Deployed Engineer track

---

## Why this challenge exists

Forward Deployed Engineers don't get clean specs. They get dropped into a business
with messy systems, a stakeholder who has a vague sense that "something is wrong,"
and a deadline. Your job is to figure out what's actually going on, build something
real, and be able to explain it to a non-technical exec in plain language.

This challenge is designed to feel like that — on purpose. The data is messy. The
brief is incomplete. That's the point.

---

## The situation

**Northstar Retail Co.** is a mid-size retailer (B2B + B2C) shipping out of three
regional warehouses: Denver (WH-01), Columbus (WH-02), and Reno (WH-03). They grew
through acquisitions and never fully unified their systems — order management,
warehouse/shipping, and customer support all live in separate tools that don't talk
to each other well.

You've received this brief from **Priya Chandra, VP of Operations**:

> "Customer complaints about deliveries are up noticeably this quarter and honestly
> we don't have a clean way to see what's going on across our systems. We pulled
> exports from our three main systems — orders, shipping/fulfillment, and support
> tickets — plus a current inventory snapshot. We need something that helps our ops
> team actually see what's going wrong and where to focus, not just another
> spreadsheet nobody opens. Whatever you can put together today would help a lot."

That's the entire brief. It is intentionally underspecified — figure out what she
actually needs, not just what she typed.

---

## What you're given

In `/data`, six CSV exports, pulled as-is from Northstar's systems (see
`01_data_dictionary.md` for column definitions):

- `orders.csv`
- `shipping_events.csv`
- `support_tickets.csv`
- `inventory_snapshot.csv`
- `customers.csv`
- `products.csv`

**Fair warning:** these are real exports, not sanitized sample data. Expect
inconsistent formatting, missing links between tables, duplicate rows, and free-text
fields that don't always agree with their own category labels. That mess is part of
the problem, not a bug in the challenge.

---

## What you're being asked to do

There is no fixed spec. At minimum, by the end of the day you should be able to
deliver:

1. **A working prototype** — dashboard, tool, script, notebook, whatever form
   factor you think best serves an ops manager who is not a data person. It should
   actually run on the provided data, not be a mockup.
2. **A live readout to the client (5 minutes)** — you will present to a judge
   playing the role of Priya (VP of Ops). Assume she has 5 minutes between
   meetings. Explain what you found, what you built, and what she should do with it
   — in plain language, not code.
3. **A one-page "what's next" note** — if you had one more week, what would you
   build next and why? This is about prioritization, not effort.

How you spend your day — how much time on data wrangling vs. analysis vs. building
vs. polish — is entirely your call. That judgment is part of what's being evaluated.

---

## Rules & logistics

- **Format:** individual, one day.
- **Tools:** any language, framework, or library you want. Use AI coding and
  analysis assistants freely — being effective with your tools is expected, not a
  shortcut we're trying to catch you taking. No pre-built "ops dashboard"
  templates or products, though — build the logic yourself.
- **Come ready to talk about how you used AI.** In your live readout, we'll ask
  where you used AI tools today and about a specific moment one of them gave you
  something wrong, incomplete, or worth double-checking — and how you caught it.
  This isn't a trick question or a gotcha about whether you used AI at all;
  we assume you did. We're interested in how you direct it and whether you verify
  what it gives you before you'd hand it to a client.
- **Data:** use only the provided CSVs. Don't look up real companies with similar
  names — Northstar, Meridian Corp, and all data here are fictional.
- **Client Q&A:** there will be one scheduled 15-minute window (see schedule) where
  you can ask a judge playing Priya up to 3 questions. Use it well — knowing what
  to ask, and when, is part of what's being evaluated.
- **New information may arrive during the day.** In a real engagement, client
  priorities shift mid-project. If that happens here, treat it as a real
  reprioritization moment, not a distraction from "the real work."

## Suggested schedule (adapt to your actual start time)

| Time | Activity |
|---|---|
| 0:00 – 0:30 | Read brief, skim data, form initial hypotheses |
| 0:30 – 0:45 | **Client Q&A window** (scheduled, per-candidate slot) |
| 0:45 – 5:00 | Build |
| ~4:00 | *(Facilitators: mid-day update may be issued here — see judge guide)* |
| 5:00 – 6:30 | Build / polish |
| 6:30 – 7:00 | Prepare one-pager and readout |
| 7:00 – end | Live client readouts (5 min + 3 min Q&A per candidate) |

---

## What "good" looks like

We are not grading on lines of code or visual polish. We're watching for:

- Did you figure out what Priya actually needs, versus what she literally typed?
- Did you prioritize the highest-leverage thing first?
- Does it actually work end-to-end on the real (messy) data?
- Did you notice and handle the data quality issues, rather than silently
  producing wrong numbers?
- Can you explain your reasoning and trade-offs to a non-technical stakeholder
  clearly and honestly, including what you didn't get to?
- How did you handle new information if it arrived mid-day?
- If you used AI tools, did you verify what they gave you before relying on it —
  and can you point to a specific moment you caught them getting something wrong?

Good luck — and welcome to what the job actually feels like.
