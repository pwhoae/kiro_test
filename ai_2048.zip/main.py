
import tkinter as tk
import random
import copy

SIZE = 4

def new_board():
    board = [[0]*SIZE for _ in range(SIZE)]
    add_tile(board)
    add_tile(board)
    return board

def add_tile(board):
    empty = [(i,j) for i in range(SIZE) for j in range(SIZE) if board[i][j]==0]
    if not empty: return
    i,j = random.choice(empty)
    board[i][j] = 2 if random.random()<0.9 else 4

def compress(row):
    new = [i for i in row if i!=0]
    new += [0]*(SIZE-len(new))
    return new

def merge(row):
    for i in range(SIZE-1):
        if row[i] and row[i]==row[i+1]:
            row[i]*=2
            row[i+1]=0
    return row

def move_left(board):
    new = []
    for row in board:
        r = compress(row)
        r = merge(r)
        r = compress(r)
        new.append(r)
    return new

def rotate(board):
    return [list(row) for row in zip(*board[::-1])]

def move(board, direction):
    b = copy.deepcopy(board)
    for _ in range(direction):
        b = rotate(b)
    b = move_left(b)
    for _ in range((4-direction)%4):
        b = rotate(b)
    return b

def get_moves(board):
    return [0,1,2,3]

def evaluate(board):
    empty = sum(row.count(0) for row in board)
    return empty

def expectimax(board, depth, player):
    if depth == 0:
        return evaluate(board)
    if player:
        best = -1e9
        for m in get_moves(board):
            b = move(board, m)
            best = max(best, expectimax(b, depth-1, False))
        return best
    else:
        empty = [(i,j) for i in range(SIZE) for j in range(SIZE) if board[i][j]==0]
        if not empty:
            return evaluate(board)
        total = 0
        for (i,j) in empty:
            for val, prob in [(2,0.9),(4,0.1)]:
                b = copy.deepcopy(board)
                b[i][j] = val
                total += prob * expectimax(b, depth-1, True)
        return total / len(empty)

def best_move(board):
    best_score = -1e9
    best = 0
    for m in get_moves(board):
        b = move(board, m)
        score = expectimax(b, 3, False)
        if score > best_score:
            best_score = score
            best = m
    return best

class Game:
    def __init__(self, root):
        self.root = root
        self.board = new_board()
        self.labels = [[tk.Label(root, width=4, height=2, font=("Arial",24)) for _ in range(SIZE)] for _ in range(SIZE)]
        for i in range(SIZE):
            for j in range(SIZE):
                self.labels[i][j].grid(row=i, column=j)
        self.update_ui()
        root.after(500, self.ai_step)

    def update_ui(self):
        for i in range(SIZE):
            for j in range(SIZE):
                val = self.board[i][j]
                self.labels[i][j].config(text=str(val) if val else "")

    def ai_step(self):
        m = best_move(self.board)
        self.board = move(self.board, m)
        add_tile(self.board)
        self.update_ui()
        self.root.after(200, self.ai_step)

root = tk.Tk()
root.title("2048 AI")
game = Game(root)
root.mainloop()
