
# 2048 AI 可视化小游戏

## 运行方法
1. 确保安装 Python 3
2. 运行：
   python main.py

## 功能
- 自动AI玩2048（Expectimax）
- 简单可视化界面（Tkinter）

## 可改进
- 更强评分函数
- 更深搜索
